const modul = require('./modul');

console.log(modul.suma(parseInt(process.argv[2]), parseInt(process.argv[3])));
