module.exports = {
  suma: function suma(x, y) {
    return x + y;
  },
};
